<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"G:\phpstudy_pro\WWW\gallery\public/../application/index\view\index\imgc.html";i:1593441817;}*/ ?>
<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>作品展示</title>
<link rel="stylesheet" type="text/css" href="../../../../public/imga/css/normalize.css" />
<link rel="stylesheet" type="text/css" href="../../../../public/imga/css/demo.css">
<link rel="stylesheet" type="text/css" href="../../../../public/imga/css/style.css">
</head>
<body>

<div class="slider" id="slider" > 
  <div class="slider__content" id="slider-content">
	<div class="slider__images">
	  <div class="slider__images-item slider__images-item--active" data-id="1"><img src="<?php echo $imgPath; ?>"></div>
	</div>
	<div class="slider__text">
	  <div class="slider__text-item slider__text-item--active" data-id="1">
		<div class="slider__text-item-head">
		  <h3><?php echo $name; ?></h3>
		</div>
		<div class="slider__text-item-info">
		  <p>摄制时间 <?php echo $date; ?></p>
		</div>
	  </div>
	</div>
  </div>
</div>

<div style="text-align:center;clear:both">

</div>

</body>
</html>