<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"G:\phpstudy_pro\WWW\gallery\public/../application/index\view\index\abc.html";i:1593167164;}*/ ?>
