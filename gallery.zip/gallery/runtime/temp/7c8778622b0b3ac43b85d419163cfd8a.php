<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"G:\phpstudy_pro\WWW\gallery\public/../application/index\view\index\index.html";i:1593442158;}*/ ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>画廊</title>
		<link rel="shortcut icon" href="../favicon.ico">

		<link rel="stylesheet" type="text/css" href="../../public/index/css/demo.css" />
		<link rel="stylesheet" type="text/css" href="../../public/index/css/gallery.css" />

		<script src="../../public/index/js/TweenMax.min.js"></script>
		<script src="../../public/index/js/jquery.min.js"></script>
	</head>
	<body>
		<svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="filters hidden">
			<defs>
			  <filter id="blur">
				  <feGaussianBlur in="SourceGraphic" stdDeviation="0,0" />
			  </filter>
			</defs>
		</svg>
		<div class="container">
		<header class="codrops-header">
			<nav class="codrops-demos">
				<a class="current-demo" href="index.html">画廊</a>
			</nav>
		</header>
			<div class="content">
				<div class="gallery">
					<ul class="gallery-pictures">
						<li class="gallery-picture">
							<a href="<?php echo url('index/imga'); ?>"><img src="<?php echo $img1Path; ?>" alt="img01"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgb'); ?>"><img src="<?php echo $img2Path; ?>" alt="img02"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgc'); ?>"><img src="<?php echo $img3Path; ?>" alt="img03"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgd'); ?>"><img src="<?php echo $img4Path; ?>" alt="img04"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imge'); ?>"><img src="<?php echo $img5Path; ?>" alt="img05"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgf'); ?>"><img src="<?php echo $img6Path; ?>" alt="img06"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgg'); ?>"><img src="<?php echo $img7Path; ?>" alt="img07"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgh'); ?>"><img src="<?php echo $img8Path; ?>" alt="img08"></a>
						</li>
						<li class="gallery-picture">
							<a href="<?php echo url('index/imgi'); ?>"><img src="<?php echo $img9Path; ?>" alt="img09"></a>
						</li>
					</ul>
					<div class="gallery-pagination">
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
						<button class="gallery-pagination-dot"></button>
					</div>
				</div>
				<div style="text-align:center;clear:both">			
				</div>
			</div>	
		</div>
		<script src="../../public/index/js/gallery.js"></script>
	</body>
</html>
