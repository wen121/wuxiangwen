<?php
namespace app\index\controller;
use think\Controller;
use think\Db;

class Index extends Controller
{
    public function index()
    {
        $data=Db::table('img')->select();
        $this->assign([
            'img1Path' => $data[0]["path"],
            'img2Path' => $data[1]["path"],
            'img3Path' => $data[2]["path"],
            'img4Path' => $data[3]["path"],
            'img5Path' => $data[4]["path"],
            'img6Path' => $data[5]["path"],
            'img7Path' => $data[6]["path"],
            'img8Path' => $data[7]["path"],
            'img9Path' => $data[8]["path"],
        ]);
        return $this->fetch();
    }
    public function imga(){
        $str="../../";
        $data=Db::table('img')->where('id',1)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgb(){
        $str="../../";
        $data=Db::table('img')->where('id',2)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgc(){
        $str="../../";
        $data=Db::table('img')->where('id',3)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgd(){
        $str="../../";
        $data=Db::table('img')->where('id',4)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imge(){
        $str="../../";
        $data=Db::table('img')->where('id',5)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgf(){
        $str="../../";
        $data=Db::table('img')->where('id',6)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgg(){
        $str="../../";
        $data=Db::table('img')->where('id',7)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgh(){
        $str="../../";
        $data=Db::table('img')->where('id',8)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
    public function imgi(){
        $str="../../";
        $data=Db::table('img')->where('id',9)->find();
 
        $this->assign([
            'imgPath' => $str.$data["path"],
            'name' => $data["name"],
            'date' => $data["date"],
        ]);
        return $this->fetch();
    }
}
